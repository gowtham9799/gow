function submits() {

  var chec = document.getElementById("box")


    var firstname = document.getElementById("fname").value;
    if (firstname == "") {
      document.getElementById("demo").innerHTML = "Enter your firstname";
    }
    else {
      document.getElementById("demo").innerHTML = " valid ";
    }
    // <!-- <-----first name over-----> 

    var lastname = document.getElementById("lname").value;
    if (lastname == "") {
      document.getElementById("demo1").innerHTML = "Enter your lastname";
    }

    else {
      document.getElementById("demo1").innerHTML = "valid";
    }
    // <!-- <----- last name over-----> 

   var email = document.getElementById("email").value;
    if (email == "") {
      document.getElementById("demo3").innerHTML = "Enter your email";
    }
    else if (!email.match((/^[a-z0-9]+[@]+[gmail]+[.]+[com]*$/))) {
      document.getElementById("demo3").innerHTML = "invalid";
    }
    else {
      document.getElementById("demo3").innerHTML = "valid";
    }
    // <!-- <-----email over-----> 

    var password = document.getElementById("password").value;
    if (password == "") {
      document.getElementById("demo4").innerHTML = "Enter your password";
    }
    else if (!password.match((/^[0-9]*$/))) {
      document.getElementById("demo4").innerHTML = "invalid";
    }
    else {
      document.getElementById("demo4").innerHTML = "valid";
    }
    // <!-- <--------password over-------->

    var confirmpassword = document.getElementById("confirmpassword").value;
    if (confirmpassword == "") {
      document.getElementById("demo5").innerHTML = "Enter your confirm password";
    }
    else if (confirmpassword == "6380355874") {
      document.getElementById("demo5").innerHTML = "invalid";
    }
    else {
      document.getElementById("demo5").innerHTML = "valid";
    }
    // <!-- <----------confirm password over--------->

    let dob = document.getElementById("dob").value;
    if (dob == "") {
      document.getElementById("demo6").innerHTML = "Enter your date of birth";
    }
    else if (dob == "06-07-1997") {
      document.getElementById("demo6").innerHTML = "invalid";
    }
    else {
      document.getElementById("demo6").innerHTML = "valid";
    }
    // <!-- <--------dob over------->

    var organization = document.getElementById("organization").value;
    if (organization == "") {
      document.getElementById("demo7").innerHTML = "Enter your organization";
    }
    else if (organization == "zefor") {
      document.getElementById("demo7").innerHTML = "invalid";
    }
    else {
      document.getElementById("demo7").innerHTML = "valid";
    }
    // <!-- <--------organization over------->

    var industry = document.getElementById("industry").value;
    if (industry == "") {
      document.getElementById("demo8").innerHTML = "Enter your industry";
    }
    else if (industry == "zefor") {
      document.getElementById("demo8").innerHTML = "invalid";
    }
    else {
      document.getElementById("demo8").innerHTML = "valid";
    }
    // <!-- <--------industry over------->

    var phonenumber = document.getElementById("phonenumber").value;
    if (phonenumber == "") {
      document.getElementById("demo9").innerHTML = "Enter your phone number";
    }
    else if (phonenumber == "6380355874") {
      document.getElementById("demo9").innerHTML = "invalid";
    }
    else {
      document.getElementById("demo9").innerHTML = "valid";
    }
    // <!-- <--------phone number over------->

    let male = document.getElementById("maless");
  let female = document.getElementById("femaless");

  if (document.getElementById("maless").checked == true || document.getElementById("femaless").checked == true || document.getElementById("others").checked == true) {
    document.getElementById("error").innerHTML = "";
    console.log("males");
  }
  else {
    document.getElementById("error").innerHTML = "invalid";
  }
  if (chec.checked == true) {
    document.getElementById("pro").innerHTML = "";
    console.log("hi")
  }
  else {
    document.getElementById("pro").innerHTML = "invalid";
  }
}


gen =()=>{
  let male = document.getElementById("maless");
  let female = document.getElementById("femaless");

  if (document.getElementById("maless").checked == true || document.getElementById("femaless").checked == true || document.getElementById("others").checked == true) {
    document.getElementById("error").innerHTML = "valid";
    console.log("males");
  }
  else {
    document.getElementById("error").innerHTML = "invalid";
  }
  if (chec.checked == true) {
    document.getElementById("pro").innerHTML = "ok";
    console.log("hi")
  }

  else {
    document.getElementById("pro").innerHTML = "invalid";
  }
}

// <------on keyup function start----->
first =()=>{
  var firstname = document.getElementById("fname").value;
  if (firstname == "") {
    document.getElementById("demo").innerHTML = "Enter your firstname";
  }
  else {
    document.getElementById("demo").innerHTML = " valid ";
  }
}


last =()=>{
  var lastname = document.getElementById("lname").value;
  if (lastname == "") {
    document.getElementById("demo1").innerHTML = "Enter your lastname";
  }

  else {
    document.getElementById("demo1").innerHTML = "valid";
  }
}


email1 =()=>{
  var email = document.getElementById("email").value;
  if (email == "") {
    document.getElementById("demo3").innerHTML = "Enter your email";
  }
  else if (!email.match((/^[a-z0-9]+[@]+[gmail]+[.]+[com]*$/))) {
    document.getElementById("demo3").innerHTML = "invalid";
  }
  else {
    document.getElementById("demo3").innerHTML = "valid";
  }
}


pass =()=>{
  var password = document.getElementById("password").value;
  if (password == "") {
    document.getElementById("demo4").innerHTML = "Enter your password";
  }
  else if (!password.match((/^[0-9]*$/))) {
    document.getElementById("demo4").innerHTML = "invalid";
  }
  else {
    document.getElementById("demo4").innerHTML = "valid";
  }
}


pass1 =()=>{
  var confirmpassword = document.getElementById("confirmpassword").value;
  if (confirmpassword == "") {
    document.getElementById("demo5").innerHTML = "Enter your confirm password";
  }
  else if (confirmpassword.match(/[0-9]{10}/)){
    document.getElementById("demo5").innerHTML = "invalid";
  }
}


dob =()=>{
  let dob = document.getElementById("dob").value;
  if (dob == "") {
    document.getElementById("demo6").innerHTML = "Enter your date of birth";
  }
  if (!dob.match(/^[0-9]{8}$/)) {
    document.getElementById("demo6").innerHTML = "else";
    document.getElementById("demo6").innerHTML = "invalid";
  }
}


org =()=>{
  var organization = document.getElementById("organization").value;
  if (organization == "") {
    document.getElementById("demo7").innerHTML = "Enter your organization";
  }
  else if (organization == "zefor") {
    document.getElementById("demo7").innerHTML = "valid";
  }
  else {
    document.getElementById("demo7").innerHTML = "valid";
  }
}



ind =()=>{
  var industry = document.getElementById("industry").value;
  if (industry == "") {
    document.getElementById("demo8").innerHTML = "Enter your industry";
  }
  else if (industry == "zefor") {
    document.getElementById("demo8").innerHTML = "invalid";
  }
  else {
    document.getElementById("demo8").innerHTML = "valid";
  }
}


pho =()=>{
  var phonenumber = document.getElementById("phonenumber").value;
 
  if (!phonenumber.match(/^[0-9]{10}$/)) {
    document.getElementById("demo9").innerHTML = "invalid";
  }
  else{
    document.getElementById("demo9").innerHTML = "valid";
  }
}



gen =()=>{
let male = document.getElementById("maless");
let female = document.getElementById("femaless");

if (document.getElementById("maless").checked == true || document.getElementById("femaless").checked == true || document.getElementById("others").checked == true) {
  document.getElementById("error").innerHTML = "";
  console.log("males");
}
else {
  document.getElementById("error").innerHTML = "invalid";
}



if (chec.checked == true) {
  document.getElementById("pro").innerHTML = "";
  console.log("hi")
}

else {
  document.getElementById("pro").innerHTML = "invalid";
}
}


function gow1(){
  var x = document.getElementById("show");
  var y = document.getElementById('password')
  if (x.innerHTML === "show") {
    x.innerHTML = "hide";
    y.type = "text"
  } else {
    x.innerHTML = "show";
    y.type = "password"
  }
}



function gow2(){
  var xx = document.getElementById("show1");
  var yx = document.getElementById('confirmpassword')
  if (xx.innerHTML === "show") {
    xx.innerHTML = "hide";
    yx.type = "text"
  } else {
    xx.innerHTML = "show";
    yx.type = "password";
  }
}
// <------on keyup function ent----->